import json
import os
import boto3
import tweepy
from tweepy import OAuthHandler
from base64 import b64decode


def lambda_handler(event, context):

    c_key_enc = os.environ['c_key']
    c_secret_enc = os.environ["c_secret"]
    tkn_env_enc = os.environ['tkn']
    tkn_secret_enc = os.environ["tkn_secret"]

    c_key = boto3.client('kms').decrypt(
        CiphertextBlob=b64decode(c_key_enc))['Plaintext']
    c_secret = boto3.client('kms').decrypt(
        CiphertextBlob=b64decode(c_secret_enc))['Plaintext']
    tkn = boto3.client('kms').decrypt(
        CiphertextBlob=b64decode(tkn_env_enc))['Plaintext']
    tkn_secret = boto3.client('kms').decrypt(
        CiphertextBlob=b64decode(tkn_secret_enc))['Plaintext']

    twitter_client_id = c_key
    twitter_secret = c_secret
    twitter_token = tkn
    twitter_token_secret = tkn_secret

    auth = OAuthHandler(twitter_client_id, twitter_secret)
    auth.set_access_token(twitter_token, twitter_token_secret)
    auth = OAuthHandler(twitter_client_id, twitter_secret)
    auth.set_access_token(twitter_token, twitter_token_secret)

    api = tweepy.API(auth)

    kinesis = boto3.client('kinesis')

    hashtag = "desafiode"
    for t in tweepy.Cursor(api.search, q=hashtag).items():
        o = json.dumps(t._json, indent=True)
        print("Inserindo registro do usuario %s" % (t._json["user"]["name"]))
        kinesis.put_record(StreamName="twitter",
                           Data=json.dumps(o), PartitionKey="filler")
